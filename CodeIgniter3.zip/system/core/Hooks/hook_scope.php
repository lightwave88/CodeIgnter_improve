<?php

namespace system;

abstract class CI_HookScope {

    abstract public function getResult();

    abstract public function checkResult($resulr);
}
