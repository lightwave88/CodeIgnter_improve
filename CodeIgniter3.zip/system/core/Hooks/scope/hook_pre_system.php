<?php

namespace system;

if (!class_exists('\system\CI_HookScope')) {
    $file = __DIR__ . '../hook_scope.php';
}

class CI_Hook_pre_system extends CI_HookScope {

    public function checkResult($resulr) {
        
    }

    public function getResult() {
        
    }

}
