<?php

namespace system;

/**
 * CodeIgniter
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2014 - 2017, British Columbia Institute of Technology
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	CodeIgniter
 * @author	EllisLab Dev Team
 * @copyright	Copyright (c) 2008 - 2014, EllisLab, Inc. (https://ellislab.com/)
 * @copyright	Copyright (c) 2014 - 2017, British Columbia Institute of Technology (http://bcit.ca/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	https://codeigniter.com
 * @since	Version 1.0.0
 * @filesource
 */
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Hooks Class
 *
 * Provides a mechanism to extend the base system without hacking.
 *
 * @package		CodeIgniter
 * @subpackage	Libraries
 * @category	Libraries
 * @author		EllisLab Dev Team
 * @link		https://codeigniter.com/user_guide/general/hooks.html
 */
class CI_Hooks {

    const HOOKSDIR = 'hooks';
    const HOOK_EXTENDSCLASS = '\system\CI_Hook';
    const HOOK_EXTENDSCLASS_PATH = 'core1/Container/HookABS.php';

    /**
     * Determines whether hooks are enabled
     *
     * @var	bool
     */
    public $enabled = FALSE;

    /**
     * List of all hooks set in config/hooks.php
     *
     * @var	array
     */
    public $hooks = array();

    /**
     * Array with class objects to use hooks methods
     * 單例的記錄
     *
     * @var array
     */
    protected $_objects = array();

    /**
     * In progress flag
     *
     * Determines whether hook is in progress, used to prevent infinte loops
     *
     * @var	bool
     */
    protected $_in_progress = FALSE;

    // -------------------------------------------------------------------------
    /**
     * Class constructor
     *
     * @return	void
     */
    public function __construct() {
        $CFG = & load_class('Config', 'core');
        log_message('info', 'Hooks Class Initialized');

        // If hooks are not enabled in the config file
        // there is nothing else to do
        if ($CFG->item('enable_hooks') === FALSE) {
            return;
        }


        // Grab the "hooks" definition file.
        if (file_exists(APPPATH . 'config/hooks.php')) {
            include(APPPATH . 'config/hooks.php');
        }

        if (file_exists(APPPATH . 'config/' . ENVIRONMENT . '/hooks.php')) {
            include(APPPATH . 'config/' . ENVIRONMENT . '/hooks.php');
        }

        // If there are no hooks, we're done.
        if (!isset($hook) OR ! is_array($hook)) {
            return;
        }

        $this->hooks = & $hook;
        $this->enabled = TRUE;
    }

    // -------------------------------------------------------------------------

    /**
     * Call Hook
     *
     * Calls a particular hook. Called by CodeIgniter.php.
     *
     * @uses	CI_Hooks::_run_hook()
     *
     * @param	string	$which	Hook name
     * @return	bool	TRUE on success or FALSE on failure
     */
    public function call_hook($which = '') {

        Console()->log('call_hook(%s)', $which);

        if (!$this->enabled OR ! isset($this->hooks[$which])) {
            return FALSE;
        }
        //------------------
        if (class_exists('\system\CI_Hook')) {
            $file = BASEPATH . 'core1/Container/HookABS.php';
            include_class($file);
        }
        //------------------

        $runList = array();

        if (is_array($this->hooks[$which]) && is_array($this->hooks[$which][0])) {
            $runList = $this->hooks[$which];
        } else {
            // 設定檔是單一
            $runList[] = $this->hooks[$which];
        }
        //------------------
        $returnVal = TRUE;

        // 執行所有 hookSetting
        // 設定檔是 array
        foreach ($runList as $k => $val) {
            try {
                $return = $this->_run_hook($val, $which, $scope);

                if ($return === FALSE) {
                    // hookSetting 回傳 FALSE 則中斷所有程序
                    exit();
                    break;
                } else if ($return instanceof \system\CI_ResultABS) {

                    // 有可能是資訊輸出
                    // cotroller, method 重導
                    //
                    $result = $res->ExecuteResult();
                    $scope->checkResult($result);
                    break;
                }
            } catch (Exception $exc) {
                $this->_in_progress = FALSE;
                $returnVal = FALSE;

                // 要根據執行環境再修改
                throw $exc;
            }
        }

        return $returnVal;
    }

    // -------------------------------------------------------------------------

    /**
     * Run Hook
     *
     * Runs a particular hook
     *
     * @param	array	$data	Hook details
     * @return	bool	TRUE on success or FALSE on failure
     */
    protected function _run_hook($data, $which, $scope) {

        printf('<p>run hook(%s)</p>', json_encode($data));
        // Closures/lambda functions and array($object, 'method') callables
        if (is_callable($data)) {
            is_array($data) ? $data[0]->{$data[1]}() : $data();

            return TRUE;
        } elseif (!is_array($data)) {
            return FALSE;
        }
        // -----------------------------------
        // Safety - Prevents run-away loops
        // -----------------------------------
        // If the script being called happens to have the same
        // hook call within it a loop can happen
        if ($this->_in_progress === TRUE) {
            return;
        }

        // Determine and class and/or function names
        $class = empty($data['class']) ? FALSE : $data['class'];

        if ($class) {
            $this->_checkClass();
            $data['function'] = $which;
        }

        $function = empty($data['function']) ? FALSE : $data['function'];
        $params = isset($data['params']) ? $data['params'] : array();
        $dir = (isset($data['filepath']) ? $data['filepath'] : self::HOOKSDIR);
        $dir = trim($dir, '\\/');

        array_unshift($params, $scope);
        // -----------------------------------
        // Set file path
        // -----------------------------------
        $error = !empty($class) ? "class($class)" : "function($function)";

        if (!isset($data['filename'])) {
            throw new \Exception(sprintf('hook[%s] %s no set filename', $which, $error));
        }

        $filepath = APPPATH . $dir . DIRECTORY_SEPARATOR . $data['filename'];
        if (!file_exists($filepath)) {
            throw new \Exception(sprintf('hook[%s] file(%s) no exists', $which, $filepath));
        }


        if (empty($function)) {
            $error = !empty($class) ? sprintf('%s->%s()', $class, $function) : $function;
            throw new \Exception(sprintf('hook[%s] %s no exists', $which, $error));
        }
        //-----------------------
        $index = \system\fun\getClassIndexName($class);
        $targetObj;
        $returnValue;

        // Call the requested class and/or function
        if ($class !== FALSE) {
            // The object is stored?
            if (!isset($this->_objects[$index])) {

                $i = 0;
                while (!class_exists($class)) {
                    if ($i++ > 0) {
                        throw new \Exception(sprintf('hook[%s] file(%s), class(%s) no exists', $which, $filepath, $class));
                    }
                    if (!file_exists($filepath)) {
                        throw new \Exception(sprintf('hook[%s] class(%s), file(%s) no exists', $which, $class, $filepath));
                    }
                    require_once($filepath);
                }

                if (!method_exists($class, $function)) {
                    throw new \Exception(sprintf('hook[%s] file(%s), %s->%s no exists', $which, $filepath, $class, $function));
                }
                // Store the object and execute the method
                $this->_objects[$index] = new $class();
            }

            $targetObj = $this->_objects[$index];

            if (!method_exists($targetObj, $function)) {
                throw new \Exception(sprintf('hook[%s] %s->%s() function no exists', $which, $class, $function));
            }
            $this->_in_progress = TRUE;
            $returnValue = call_user_func_array(array($targetObj, $function), $params);
        } else {

            $i = 0;
            while (!function_exists($function)) {
                if ($i++ > 0) {
                    throw new \Exception(sprintf('hook[%s] file(%s), function(%s) no exists', $which, $filepath, $function));
                }
                if (!file_exists($filepath)) {
                    throw new \Exception(sprintf('hook[%s] file(%s) no exists', $which, $filepath));
                }
                require_once($filepath);
            }

            $this->_in_progress = TRUE;
            $returnValue = call_user_func_array($function, $params);
        }

        $this->_in_progress = FALSE;
        return $returnValue;
    }

    // -------------------------------------------------------------------------
    protected function _checkClass() {
        if (class_exists(self::HOOK_EXTENDSCLASS)) {
            return;
        }
        $file = BASEPATH . self::HOOK_EXTENDSCLASS_PATH;
        require_once($file);
    }

    // -------------------------------------------------------------------------
    protected function _instanceStage() {
        
    }

    // -------------------------------------------------------------------------
    /**
     * 根據回傳的重導決定該如何做
     * 
     * @param type $which
     * @param type $result
     */
    protected function _checkResult($which, $result) {
        
    }

}
