<?php

namespace system\fun;

////////////////////////////////////////////////////////////////////////////////
//
// 不想對外的函式，系統內部的函式
// 放這邊
//
////////////////////////////////////////////////////////////////////////////////
function getCoreSetting($key) {
    static $core_settings;

    if (!isset($core_settings)) {
        $file = BASEPATH . 'config/core_settings.php';
        require_once($file);
        $core_settings = $config;
    }

    $res = isset($core_settings[$key]) ? $core_settings[$key] : NULL;
    return $res;
}

//------------------------------------------------------------------------------
function get_instance_class() {
    $CI = get_instance();
    return get_class($CI);
}

//------------------------------------------------------------------------------

function &load_spec_class($className, $path, $param = array()) {
    $g_class = get_instance_class();
    return $g_class::load_spec_class($className, $path, $param);
}

//------------------------------------------------------------------------------
function &get_classKeyMaker() {
    static $classKeyMaker;

    if (!isset($classKeyMaker)) {
        $file = BASEPATH . 'core1/LoadClassKeyMaker.php';
        include_class($file, '\system\CI_LoadClassKeyMaker');
        $classKeyMaker = new \system\CI_LoadClassKeyMaker();
    }
    return $classKeyMaker;
}

//------------------------------------------------------------------------------
/**
 * 為 class 取得一個索引名稱
 *
 * @param type $class
 * @param type $prefix: [true:用預設的 prefix|string:自訂的prefix]
 * @return type
 */
function getClassIndexName($class, $prefix = FALSE) {
    $obj = &get_classKeyMaker();
    return $obj->getClassIndexName($class, $prefix);
}

//------------------------------------------------------------------------------
/**
 * 把 moduleName 統一規格化
 *
 * @param type $moduleName
 * @return type
 */
function checkModuleName($moduleName) {
    $obj = &get_classKeyMaker();
    return $obj->checkModuleName($moduleName);
}

//------------------------------------------------------------------------------
/**
 * 把 moduleName 正規化為變數名稱
 *
 * @param type $module
 * @return type
 */
function getModuleVarName($module) {
    $obj = &get_classKeyMaker();
    return $obj->getModuleVarName($module);
}

// ------------------------------------------------------------------------

function set_context(\system\CI_Context $context) {
    $class = get_instance_class();
    $class::set_context($context);
}

//------------------------------------------------------------------------------
function callController($subdir, $class, $method = NULL, array $params) {

    // 實例化 controller
    // 取出 interceptor setting
    // 執行 interceptor
    // 執行 controller->method()
    // 執行 interceptor
    // 返回 controller->method() 結果
    //----------------------------

    if (empty($subdir)) {
        $subdir = '';
    }

    if (!empty($subdir)) {
        $subdir = trim($suXbdir, '\\/');
        $subdir = $subdir . '\\';
    }

    if (empty($method)) {
        $method = 'index';
    }

    $class = ucfirst($class);

    if (empty($params)) {
        $params = array();
    }

    $className = '\app\controllers\\' . $subdir . $class;
    $file = APPPATH . 'controllers/' . $subdir . $class . '.php';

    if (!class_exists('\system\CI_Controller')) {
        $path = BASEPATH . 'core1/Container/Controller.php';
        \include_class($path, '\system\CI_Controller');
    }
    //------------------
    if (!file_exists($file)) {
        throw new \Exception('no controller file');
    }

    include($file);

    $controller = new $className();

    // Console()->dump($controller);
    // print('<p>----------------------------</p>');


    $result = call_user_func_array(array(&$controller, $method), $params);

    return array(
        'controller' => $controller,
        'result' => $result
    );
}
