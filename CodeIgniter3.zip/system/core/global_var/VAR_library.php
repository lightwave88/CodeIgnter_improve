<?php

/**
 * 全域類別
 */
class Lib {

    /**
     * 要映射的主體
     *
     * @var type
     */
    public static $_ci_instance;

    public static function __callStatic($name, $arguments) {
        
    }
}
