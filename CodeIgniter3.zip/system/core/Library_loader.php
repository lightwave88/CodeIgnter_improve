<?php

namespace system;

/**
 * 全域類別
 */
class CI_Library_loader {

    protected static $instance;

    /**
     * 預設 lib.path
     *
     * @var type
     */
    protected $_ci_library_paths = array(APPPATH, BASEPATH);

    /**
     * core 的單一實例
     *
     * @var type
     */
    protected $_ci_single_cores = array();

    /**
     * 單一物件
     *
     * @var type
     */
    protected $_ci_single_classes = array();

    /**
     * libs 的單例
     *
     * @var array
     */
    protected $_ci_single_libs = array();
    
    
    protected $_ci_classes = array();

    //--------------------------------------------------------------------------

    private function __construct() {

        if (!class_exists('\Library')) {
            $file = BASEPATH . '/core/global_var/VAR_library.php';
            require_once($file);
            \Lib::$_ci_instance = &$lib;
        }

        if (!class_exists('\system\CI_Library')) {
            /**
             * 新 library 要用的
             */
            $file = BASEPATH . 'core1/Library.php';
            \include_class($file, '\system\CI_Library');
        }
    }

    public function load($muduleName, $params = NULL, $single = TRUE) {
        
    }

    public function bind($container, $muduleName, $params = NULL, $single = TRUE) {
        
    }

    public function singleton($muduleName, $params = NULL) {
        
    }

    public function singleton_bind() {
        
    }

    //--------------------------------------------------------------------------
    public static function &get_instance() {
        if (!isset(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    //--------------------------------------------------------------------------
    public static function &get_var($var) {
        return self::$var;
    }

    //--------------------------------------------------------------------------
    /**
     * 主要為了
     * load->is_loaded()
     *
     * @param type $className: [模組名稱|$class全名]
     * @param type $direct: [core|libraries]
     * @return [boolean|array()]
     */
    public static function &is_loaded($moduleName = '') {

        $lib = &self::get_instance();

        $index = \system\fun\getModuleVarName($moduleName);
        $lib->_ci_classes[$index] = $moduleName;

        return $lib->_ci_classes;
    }

    //--------------------------------------------------------------------------
    /**
     * 多為 core1 用
     *
     * @param type $className
     * @param type $path
     * @param array $param
     * @param type $single
     * @return type
     */
    public static function &load_spec_class($className, $path, $param = array(), $single = FALSE) {

        $lib = &self::get_instance();

        if (!is_array($param)) {
            $param = array();
        }
        //------------------
        $i = 0;
        while (!class_exists($className)) {
            if ($i < 1) {
                if (!file_exists($path)) {
                    $error = sprintf('no file %s', $path);
                    throw new \Exception($error);
                }
                require_once($path);
            } else {
                $error = sprintf('no class %s', $className);
                throw new \Exception($error);
            }
            $i++;
        }
        //------------------

        $_classes = &$lib->_ci_single_classes;
        // 索引名稱
        $indexName = \system\fun\getClassIndexName($className, TRUE);
        //------------------
        if ($single == TRUE) {

            if (isset($_classes[$indexName])) {
                return $_classes[$indexName];
            }

            // self::is_loaded($indexName);

            $instance = &\intance_class($className, $param);
            $_classes[$indexName] = &$instance;
        } else {
            $instance = &\intance_class($className, $param);
        }
        return $instance;
    }

    //--------------------------------------------------------------------------

    /**
     * 把 load_class() 導到此處
     * core, library 約定俗成的(單例 instance)方式
     *
     *
     * @param type $class
     * @param type $directory
     * @param type $param
     * @param type $single: 是否是單例
     * @return type
     */
    public static function &init_load_class($class, $directory = 'libraries', $param = NULL) {

        $single = TRUE;

        $directory = trim($directory, '/\\');

        $instance = NULL;

        $class = \system\fun\checkModuleName($class);

        // printf('<p>$class=%s, $direct=%s</p>', $class, $directory);

        if (preg_match('/^core$/', $directory)) {
            $instance = &self::_ci_load_core($class, $param, $single);
        } else {
            $instance = &self::_ci_load_lib($class, $param, $single);
        }
        //-----------------------

        $varName = \system\fun\getModuleVarName($class);

        $CI = &get_instance();

        $CI->$varName = &$instance;
        $CI->_ci_classes[$varName] = $class;

        return $instance;
    }

    //--------------------------------------------------------------------------
    /**
     * core 因為沒有對外公開
     * 所以不需要複雜的子目錄結構
     *
     *
     * @param type $class
     * @param type $param
     * @param type $single
     * @return type
     */
    protected static function &_ci_load_core($class, $param, $single) {
        $single = !!$single;

        $prefix = config_item('subclass_prefix');

        $lib = &self::get_instance();

        $moduleName = \system\fun\checkModuleName($class);

        // $class = ucfirst($class);
        //-----------------------

        $_classes = &$lib->_ci_single_cores;

        if ($single && isset($_classes[$moduleName])) {
            return $_classes[$moduleName];
        }
        //-----------------------
        $pathList = array();

        $pList = array(
            'core\\',
            ('core\\' . $class . '\\')
        );

        $fileName = $class . '.php';

        // array(APPPATH, BASEPATH)
        foreach ($lib->_ci_library_paths as $dir) {
            foreach ($pList as $d) {
                $pathList[] = $dir . $d . $fileName;
            }
        }
        //-----------------------
        $className = NULL;

        $index = NULL;
        foreach ($pathList as $k => $file) {
            if (file_exists($file)) {
                $index = $k;
                require_once($file);
                break;
            }
        }

        if (!isset($index)) {
            throw new \Exception(sprintf('module(%s) file no exists', $moduleName));
        }

        $className = '\system\\' . 'CI_' . $class;
        if (!class_exists($className)) {
            throw new \Exception(sprintf('module(%s) class(%s) no exists', $moduleName, $className));
        }

        if ($index > 1) {
            $index = $index % 2;

            $fileName = $prefix . $class . '.php';
            $file = $pathList[$index] . $fileName;

            if (file_exists($file)) {
                require_once($file);
                $className = '\system\\' . $prefix . $class;

                if (!class_exists($className)) {
                    throw new \Exception(sprintf('module(%s) class(%s) no exists', $moduleName, $className));
                }
            }
        }
        //-----------------------
        if ($single) {
            // self::is_loaded($indexName);
        }

        $inctance = isset($param) ? new $className($param) : new $className();

        if ($single) {
            // 單例需要登錄

            $_classes[$moduleName] = &$inctance;

            // 修改過的地方
            // 記錄完整的 className
            $className = get_class($_classes[$moduleName]);
            $className = \system\fun\getClassIndexName($className, TRUE);

            // self::is_loaded($className);
            $_classes[$className] = &$_classes[$moduleName];

            $varName = \system\fun\getModuleVarName($moduleName);
        }
        //------------------
        return $inctance;
    }

    //--------------------------------------------------------------------
    /**
     * lib 是公開給使用者
     * 所以會有複雜子目錄，方便使用者組織
     *
     * @param type $class
     * @param type $param
     * @param type $single
     * @return \system\libraries
     */
    protected static function &_ci_load_lib($class, $param = NULL, $single) {

        $single = !!$single;

        $lib = &self::get_instance();

        $moduleName = \system\fun\checkModuleName($class);

        $_classes = &$lib->_ci_single_libs;

        if ($single && isset($_classes[$moduleName])) {
            return $_classes[$moduleName];
        }
        //------------------
        // 確定是否有子目錄
        // 子目錄
        $subdir = '';


        // 若 lib 在 config 中有設置參數的文件
        $lib_config_file = $moduleName;
        //------------------
        $last_slash = strrpos($moduleName, '\\');

        if (isset($last_slash)) {
            $subdir = substr($class, 0, ++$last_slash);
            $class = substr($class, $last_slash);
        }

        //------------------
        // 載入檔案

        $className = self::_ci_load_stock_lib($subdir, $class);

        if (empty($className)) {
            $className = self::_ci_load_user_lib($subdir, $class);
        }

        if (empty($className)) {
            throw new \Exception(sprintf('lib(%s) no class(%s)', $moduleName, $className));
        }
        //-----------------------
        // 檢查是否有相關的 config 文件

        $core_config = load_class('Config', 'core');

        if (is_array($core_config->_config_paths)) {
            $configFileList = array();

            $fileName_1 = strtolower($lib_config_file) . '.php';
            $fileName_2 = ucfirst(strtolower($lib_config_file)) . '.php';

            $basePath = 'config/libraries/' . $subdir . '/';
            $configFileList[] = $basePath . $fileName_1;
            $configFileList[] = $basePath . $fileName_2;

            $basePath = 'config/' . ENVIRONMENT . '/libraries/' . $subdir . '/';
            $configFileList[] = $basePath . $fileName_1;
            $configFileList[] = $basePath . $fileName_2;

            foreach ($core_config->_config_paths as $path) {
                foreach ($configFileList as $_path) {
                    $file = $path . $_path;

                    if (file_exists($file)) {
                        include($file);
                    }
                }
            }
        }

        if (isset($config) && !is_array($config)) {
            $config = array();
        }

        if (is_array($param)) {
            $config = array_merge($config, $param);
        }
        //-----------------------

        $class_ref = new \ReflectionClass($className);
        $class_constrcutor = $class_ref->getConstructor();

        $fun = function($className, $config) {
            // 實例化 library
            return isset($config) ? new $className($config) : new $className();
        };

        if (isset($class_constrcutor) && !$class_constrcutor->isPublic()) {
            // 若 lib 宣告自己是唯一的單例
            $single = TRUE;

            $fun = function($className, $config) {
                // 實例化 library
                return $className::get_instance($config);
            };
        }

        if ($single) {
            // self::is_loaded($indexName);
        }

        $instance = $fun($className, $config);
        //-----------------------
        if ($instance instanceof \system\libraries) {
            // 新 library 的執行方式
            // 避免模組相互依賴的問題
            $instance->initialize();
        }

        if ($single) {
            $_classes[$moduleName] = &$instance;

            // 重要修改地方
            $className = get_class($_classes[$moduleName]);
            $className = \system\fun\getClassIndexName($className, TRUE);

            // self::is_loaded($className);
            $_classes[$className] = &$instance;
        }
        //------------------
        return $instance;
    }

    //--------------------------------------------------------------------

    /**
     * 系統預設的 lib
     *
     * @param type $subdir
     * @param type $class
     * @return type
     */
    protected static function _ci_load_stock_lib($subdir, $class) {

        $prefix = config_item('subclass_prefix');

        $className = self::_ci_checkLib_namespace($subdir, $class, 'CI_');

        if (isset($className)) {
            $_className = self::_ci_checkLib_namespace($subdir, $class, $prefix);
            if (isset($_className)) {
                $className = $_className;
            }
            return $className;
        }
        //------------------
        $className = NULL;

        $pathList = array();
        $pathList[] = 'libraries\\' . $subdir;
        $pathList[] = 'libraries\\' . $subdir . $class . '\\';

        $index = NULL;

        $fileName = $class . '.php';
        // 檢查 BASEPATH/libraries
        foreach ($pathList as $k => $file) {
            $file = BASEPATH . $file . $fileName;
            if (file_exists($file)) {
                $index = $k;
                break;
            }
        }
        //------------------
        if (!isset($index)) {
            // 沒有系統的 lib
            return NULL;
        }
        //------------------
        // 檢查 APPPATH/libraries
        // 是否有覆蓋原系統的 lib

        $file = APPPATH . $pathList[$index] . $fileName;

        if (file_exists($file)) {
            require_once($file);

            $className = self::_ci_checkLib_namespace($subdir, $class, 'CI_');

            if (!isset($className)) {
                throw new \Exception(sprintf('library(%s) file(%s) exists, but class error', $class, $file));
            }
            return $className;
        }
        //------------------
        // 沒有覆蓋原系統的 lib
        $file = BASEPATH . $pathList[$index] . $fileName;
        require_once($file);

        $className = self::_ci_checkLib_namespace($subdir, $class, 'CI_');
        if (!isset($className)) {
            throw new \Exception(sprintf('library(%s) file(%s) exists, but class error', $class, $file));
        }

        $namespace = '';

        $last_slash = strrpos($className, '\\');
        if ($last_slash !== FALSE) {
            $namespace = substr($className, 0, $last_slash + 1);
        }

        $fileName = $prefix . $class . '.php';
        $file = APPPATH . $pathList[$index] . $fileName;

        if (file_exists($file)) {
            require_once($file);

            $className = $namespace . $prefix . $class;
            if (!class_exists($className)) {
                throw new \Exception(sprintf('library(%s) file(%s) exists, but class error', $class, $file));
            }
        }

        return $className;
    }

    //--------------------------------------------------------------------------
    /**
     * 使用者寫的 lib
     *
     * @param type $subdir
     * @param type $class
     */
    protected static function _ci_load_user_lib($subdir, $class) {
        $className = '\\library\\' . $subdir . $class;

        if (class_exists($className)) {
            return $className;
        }
        //------------------

        $pathList = array();

        $pathList[] = APPPATH . 'libraries\\' . $subdir;
        $pathList[] = APPPATH . 'libraries\\' . $subdir . $class . '\\';

        $res = NULL;

        $fileName = $class . '.php';
        foreach ($pathList as $path) {
            $file = $path . $fileName;

            if (file_exists($file)) {
                require_once($file);

                $res = $className;
                if (!class_exists($className)) {
                    throw new \Exception(sprintf('library(%s) file(%s) exists, but class error', $class, $file));
                }
                break;
            }
        }
        return $res;
    }

    //--------------------------------------------------------------------------
    /**
     * lib 有可能有兩種 namspace
     * 一種 全域 namespace(預設)
     * 一種 新增的 \libraries\
     *
     * @param type $subdir
     * @param type $moduleName
     * @param type $prefix
     * @return string
     */
    protected static function _ci_checkLib_namespace($subdir, $moduleName, $prefix = '') {
        $namespace = array();
        $namespace[] = '\\library\\' . $subdir;
        $namespace[] = '\\';

        $className = $prefix . $moduleName;
        $res = NULL;

        foreach ($namespace as $value) {
            $class = $value . $className;
            if (class_exists($class)) {
                $res = $class;
                break;
            }
        }
        return $res;
    }

    //--------------------------------------------------------------------------
}
