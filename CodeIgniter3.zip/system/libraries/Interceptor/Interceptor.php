<?php

namespace libraries;

/**
 * 對外的接口
 */
class CI_Interceptor extends CI_Library {

    public function __construct() {
        
    }

    protected function initialize() {
        
    }

}
