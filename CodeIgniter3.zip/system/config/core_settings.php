<?php

$config['core_loadList'] = array(
    'Benchmark',
    'Config',
    'Input',
    'Lang',
    'Log',
    'Router',
    'Utf8',
    'URI',
    'Security'
);
