<?php

namespace system;

defined('BASEPATH') OR exit('No direct script access allowed');

abstract class CI_ContainerABS {

    /**
     * List of loaded classes
     *
     * @var	array
     */
    public $_ci_classes = array();
    //-----------------------

    /**
     * load 模組
     *
     * @var object
     */
    public $load;

    /**
     * 預設資料庫
     *
     * @var type
     */
    public $db;

    /**
     * 放置 model
     *
     * @var array
     */
    public $M = array();

    //--------------------------------------------------------------------------

    final protected static function injectCore($target) {

        $core_loadList = \system\fun\getCoreSetting('core_loadList');

        foreach ($core_loadList as $moduleName) {

            $varName = \system\fun\getModuleVarName($moduleName);

            $core = &\load_class($moduleName, 'core');

            $target->$varName = &$core;

            $target->_ci_classes[$varName] = $moduleName;
        }
    }

}

//------------------------------------------------------------------------------
/**
 * Model, interceptor, Hook
 */
abstract class CI_Container extends CI_ContainerABS {

    public $_ci_scope;

    public function getScope() {
        return $this->_ci_scope;
    }

    public function setScope($scope) {
        $this->_ci_scope = $scope;
    }

}
