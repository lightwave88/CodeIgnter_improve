<?php

namespace system;

use system\funs;

defined('BASEPATH') OR exit('No direct script access allowed');

if (!class_exists('CI_ContainerABS')) {
    require_once(__DIR__ . '/ContainerABS.php');
}

/**
 * Description of CI_Controller
 *
 * @author xman
 */
abstract class CI_Controller extends CI_ContainerABS {

    public $_ci_interceptor;

    //--------------------------------------------------------------------------
    //put your code here
    public function __construct() {
        parent::__construct();

        \system\fun\set_context($this);

        foreach (self::$_ci_core_loadList as $coreName) {
            $varName = strtolower($coreName);
            $this->$varName = &load_class($coreName, 'core');
        }

        $file = BASEPATH . 'core1/Loader/Loader_LV2.php';
        $this->load = \system\fun\load_spec_class('\system\Loader_LV2', $file, array($this));
    }

    //--------------------------------------------------------------------------
    /**
     * 呼叫 conroller 取得網頁內容
     *
     * @param type $controller
     * @param type $method
     * @param array $args
     */
    protected function callController($controller, $method = NULL, array $args = array()) {

        $CI = get_instance();

        // 找到 controller class
        $cotroller = &funs\load_Controller($controller);

        // 實例化 controller
        // 取出 interceptor setting
        // 執行 interceptor
        // 執行 controller->method()
        // 執行 interceptor
        // 返回 controller->method() 結果

        $CI->set_context($this->_ci_context);
        $CI->set_container($this);
    }

    //--------------------------------------------------------------------------
    protected function setInterceptor($interceptors) {

    }

    //--------------------------------------------------------------------------
}
