<?php

namespace system;

if (class_exists('CI_Container')) {
    require_once(__DIR__ . '/ContainerABS.php');
}

/**
 * hook class 必須繼承
 * 方便經過 __get() 與 globalContext 連接
 *
 * 結構如舊的 model 是連接依靠到 controller
 */
abstract class CI_Hook extends CI_Container {

    public function __construct() {
        $CI = &get_instance();

        self::injectCore($this);

        $className = '\system\CI_Loader_LV2';
        $path = BASEPATH . '/core1/Loader/Loader_LV2.php';
        $this->load = \system\fun\load_spec_class($className, $path, array($this));
    }

    // -------------------------------------------------------------------------
}
