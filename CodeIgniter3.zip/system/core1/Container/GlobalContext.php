<?php

namespace system;

defined('BASEPATH') OR exit('No direct script access allowed');

if (!class_exists('CI_ContainerABS')) {
    require_once(__DIR__ . '/ContainerABS.php');
}

/**
 * Description of CI_GlobalContext
 *
 * @author xman
 */
final class CI_GlobalContext extends CI_ContainerABS {

    private static $instance;

    /**
     * 現在運行時的上下文
     *
     * @var type
     */
    public static $_ci_running_context;
    //------------------
    /**
     * List of loaded models
     *
     * @var	array
     */
    public $_ci_single_models = array();

    /**
     * List of loaded helpers
     *
     * @var	array
     */
    public $_ci_single_helpers = array();

    //--------------------------------------------------------------------------
    public function __construct() {

        $file = BASEPATH . 'core1/Loader/Loader_LV1.php';
        \include_class($file, '\system\CI_Loader_LV1');
        $this->load = new \system\CI_Loader_LV1($this);
    }

    //--------------------------------------------------------------------------
    // 返回一個全域對象
    public static function &get_instance() {
        if (!isset(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    //--------------------------------------------------------------------------

    static public function &load_model($model, $db_conn = FALSE, $single = TRUE) {

        if (empty($model)) {
            return $this;
        }
        //------------------
        $CI = self::$instance;
        $_ci_models = &$CI->_ci_models;

        $model = preg_replace('/\\/', '\\', $model);
        $model = ltrim($model, '\\');

        $indexName = strtolower($model);

        if (key_exists($indexName, $_ci_models, TRUE)) {
            return $_ci_models[$indexName];
        }
        //------------------

        $path = '';

        // Is the model in a sub-folder? If so, parse out the filename and path.

        $last_slash = strrpos($model, '\\');
        if ($last_slash !== FALSE) {
            // The path is in front of the last slash
            $path = substr($model, 0, $last_slash + 1);

            // And the model name behind it
            $modelClass = substr($model, $last_slash + 1);
        } else {
            $modelClass = $model;
        }
        //------------------

        if ($db_conn !== FALSE && !class_exists('CI_DB', FALSE)) {
            if ($db_conn === TRUE) {
                $db_conn = '';
            }
            // 連線
            $this->database($db_conn, FALSE, TRUE);
        }
        //------------------

        if (!class_exists('\system\CI_Model', FALSE)) {

            $app_path = APPPATH . 'core' . DIRECTORY_SEPARATOR;
            if (file_exists($app_path . 'Model.php')) {
                require_once($app_path . 'Model.php');
                if (!class_exists('CI_Model', FALSE)) {
                    throw new RuntimeException($app_path . "Model.php exists, but doesn't declare class CI_Model");
                }
            } elseif (!class_exists('CI_Model', FALSE)) {
                require_once(BASEPATH . 'core' . DIRECTORY_SEPARATOR . 'Model.php');
            }

            $class = config_item('subclass_prefix') . 'Model';
            if (file_exists($app_path . $class . '.php')) {
                require_once($app_path . $class . '.php');
                if (!class_exists($class, FALSE)) {
                    throw new RuntimeException($app_path . $class . ".php exists, but doesn't declare class " . $class);
                }
            }
        }
        //------------------

        $model = ucfirst($model);
        if (!class_exists($model, FALSE)) {
            foreach ($this->_ci_model_paths as $mod_path) {
                if (!file_exists($mod_path . 'models/' . $path . $model . '.php')) {
                    continue;
                }

                require_once($mod_path . 'models/' . $path . $model . '.php');
                if (!class_exists($model, FALSE)) {
                    throw new RuntimeException($mod_path . "models/" . $path . $model . ".php exists, but doesn't declare class " . $model);
                }
                break;
            }

            if (!class_exists($model, FALSE)) {
                throw new RuntimeException('Unable to locate the model you have specified: ' . $model);
            }
        } elseif (!is_subclass_of($model, 'CI_Model')) {
            throw new RuntimeException("Class " . $model . " already exists and doesn't extend CI_Model");
        }
        //------------------
        $instance = new $model();
        $_ci_models[$indexName] = &$instance;

        $clasName = get_class($instance);
        $clasName = $clasName;

        $_ci_models[$clasName] = &$instance;
    }

    //--------------------------------------------------------------------
    public static function &load_fun($name) {

        $wrap = ($wrap === TRUE ? TRUE : FALSE);

        $indexName = strtolower($name);

        $CI = self::$instance;
        $_funs = &$CI->_ci_singleFuns();

        if (key_exists($indexName, $_funs)) {
            return $_funs[$indexName];
        }
        //------------------
        $class = sprintf('\fun\CI_%s', ucfirst($name));

        $fileName = ucfirst($name);

        $fileList = array();

        $_path = APPPATH . 'funs/' . $fileName . '.php';
        $fileList[$_path] = $class;

        $_path = BASEPATH . 'funs/' . $fileName . '.php';
        $fileList[$_path] = $class;

        $subclass_prefix = config_item('subclass_prefix');

        $class = sprintf('\funs\%s_%s', $subclass_prefix, ucfirst($name));
        $fileName = $subclass_prefix . ucfirst($name);
        $_path = APPPATH . 'funs/' . $fileName . '.php';

        $fileList[$_path] = $class;

        $className = self::includeSysFile($pathList);
        //------------------
        $_funs[$indexName] = function() use ($className) {
            $className;
        };

        return $_funs[$indexName];
    }

}
