<?php

namespace system;

defined('BASEPATH') OR exit('No direct script access allowed');

if (!class_exists('CI_ItemContainer')) {
    require_once(__DIR__ . '/ContainerABS.php');
}

class CI_Model extends CI_ItemContainer {

    public function __construct(CI_ModelContainer $context = NULL) {
        parent::__construct($context);
    }

    public function __get($key) {

        if (preg_match('/^(?:load)$/', $subject)) {
            return $_ci_context->$key;
        } else if (isset($this->$key)) {
            return $this->$key;
        } else {
            return $_ci_context->$key;
        }
    }

    public function __set($key, $value) {
        
    }

}
