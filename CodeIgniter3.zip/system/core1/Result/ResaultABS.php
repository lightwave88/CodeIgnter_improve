<?php

namespace system;

abstract class CI_ResultABS {

    /**
     * 所屬的 controller
     * 
     * @var type 
     */
    public $_ci_controller;

    abstract public function ExecuteResult();
}
