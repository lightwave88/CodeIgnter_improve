<?php

namespace system;

defined('BASEPATH') OR exit('No direct script access allowed');

if (!class_exists('CI_Loader')) {
    require_once(__DIR__ . '/Loader.php');
}

/**
 * 藍圖
 * controller 專屬的 load
 */
abstract class CI_ControllerLoaderABS extends CI_Loader {

    public function layout();

    public function view();

    public function vars($vars, $val = '');

    public function clear_vars();

    public function get_var($key);

    public function get_vars();
}
