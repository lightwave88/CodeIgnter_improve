<?php

namespace system;

defined('BASEPATH') OR exit('No direct script access allowed');

if (!class_exists('CI_Loader_LV1_ABS')) {
    require_once(__DIR__ . '/Loader_LV1_ABS.php');
}

/**
 * GlobaContext 專用
 *
 */
class CI_Loader_LV1 extends CI_Loader_LV1_ABS {

    public function __construct(CI_ContainerABS $container) {
        parent::__construct($container);
    }

    //--------------------------------------------------------------------------

    public function library($moduleName, $params = NULL, $name = NULL, $single = TRUE) {

        if (empty($name)) {
            $name = $moduleName;
        }

        $varName = \system\fun\getModuleVarName($name);
        $moduleName = \system\fun\checkModuleName($moduleName);
        //------------------
        $lib = &\Lib::_ci_load_lib($moduleName, $params, $single);
        //------------------
        $target = $this->_ci_container;

        if (isset($target->$varName) && $target->$varName === $lib) {
            return $this;
        }

        $target->$varName = &$lib;

        // is_loaded
        $_ci_classes = &$this->_ci_container->_ci_classes;

        // 登記 varName
        $_ci_classes[$name] = &$moduleName;

        // 登記 className
        $class = get_class($lib);
        $class = \system\fun\getClassIndexName($class, TRUE);
        $class = strtolower($class);

        $_ci_classes[$class] = &$moduleName;

        if (strcasecmp($name, $moduleName) != 0) {
            // 登記 moduleName
            $name = \system\fun\getModuleVarName($moduleName);
            $_ci_classes[$name] = &$moduleName;
        }

        return $this;
    }

    //--------------------------------------------------------------------------
    public function lib($moduleName, $params = NULL, $object_name = NULL, $single = TRUE) {
        return $this->library($moduleName, $params, $object_name, $single);
    }

    //--------------------------------------------------------------------------
    public function app($object_name, $class, $params = NULL, $name = NULL, $single = TRUE) {
        
    }

    //--------------------------------------------------------------------------
    public function config($file, $use_sections = FALSE, $fail_gracefully = FALSE) {
        
    }

    //--------------------------------------------------------------------------
    public function database($params = '', $return = FALSE, $query_builder = NULL) {
        // 重點
    }

    //--------------------------------------------------------------------------
    public function dbforge($db = NULL, $return = FALSE) {
        
    }

    //--------------------------------------------------------------------------
    public function dbutil($db = NULL, $return = FALSE) {
        
    }

    //--------------------------------------------------------------------------
    public function driver($library, $params = NULL, $object_name = NULL) {
        
    }

    //--------------------------------------------------------------------------
    public function file($path, $return = FALSE) {
        // 重點
    }

    //--------------------------------------------------------------------------
    public function helper($helpers = array()) {
        
    }

    //--------------------------------------------------------------------------
    public function helpers($helpers = array()) {
        
    }

    //--------------------------------------------------------------------------
    /**
     * 是否有注入過
     *
     * @param type $class
     * @return type
     */
    public function is_loaded($moduleName) {

        if (preg_match('/(.*)::class$/', $subject)) {
            $varName = strtolower($moduleName);
        } else {
            $varName = \system\fun\getModuleVarName($moduleName);
        }

        $_ci_classes = $this->_ci_container->_ci_classe;

        foreach ($_ci_classes as $key => $value) {
            if (strnatcmp($varName, $key) == 0 && isset($this->$key)) {
                return $key;
            }
        }
        return FALSE;
    }

    //--------------------------------------------------------------------------
    public function language($files, $lang = '') {
        
    }

    //--------------------------------------------------------------------------
    public function model($model, $name = NULL, $db_conn = FALSE, $single = TRUE) {
        // 重點
    }

    //--------------------------------------------------------------------------

    /**
     * Get Package Paths
     *
     * Return a list of all package paths.
     *
     * @param	bool	$include_base	Whether to include BASEPATH (default: FALSE)
     * @return	array
     */
    public function get_package_paths($include_base = FALSE) {

        throw new \Exception('fix here');
        $container = $this->_ci_container;
        return ($include_base === TRUE) ? $container->_ci_library_paths : $container->_ci_model_paths;
    }

    //--------------------------------------------------------------------------
    /**
     * CI Component getter
     *
     * Get a reference to a specific library or model.
     *
     * @param 	string	$component	Component name
     * @return	bool
     */
    protected function &_ci_get_component($component) {
        $CI = &$this->_ci_container;
        return $CI->$component;
    }

}
