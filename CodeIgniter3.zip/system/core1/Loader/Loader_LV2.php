<?php

namespace system;

defined('BASEPATH') OR exit('No direct script access allowed');

if (!class_exists('\system\CI_Loader_LV1')) {
    require_once(__DIR__ . '/Loader_LV1.php');
}

/**
 * 針對 context 是 $CI 的 container
 * 如 HookContainer
 */
class CI_Loader_LV2 extends CI_Loader_LV1 {

    public function __construct(CI_ContainerABS $container) {
        parent::__construct($container);
    }

}
