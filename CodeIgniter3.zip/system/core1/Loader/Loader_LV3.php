<?php

namespace system;

defined('BASEPATH') OR exit('No direct script access allowed');

if (!class_exists('\system\CI_Loader_LV2')) {
    require_once(__DIR__ . '/Loader_LV2.php');
}

/**
 * 針對有 context 的container
 * 如 model, interceptor
 */
class CI_Loader_LV3 extends CI_Loader_LV2 {

    
}
