<?php

namespace system;

defined('BASEPATH') OR exit('No direct script access allowed');

if (!class_exists('CI_ControllerLoaderABS')) {
    require_once(__DIR__ . '/ControllerLoaderABS.php');
}

class CI_ControllerLoader extends CI_BasicContainerLoader {

}
