<?php

namespace system;

/**
 * 處理 class 相對的 indexKey
 */
class CI_LoadClassKeyMaker {

    /**
     * library 需要轉換的 varname
     *
     * @var	array
     */
    public $_ci_varmap = array(
        'unit_test' => 'unit',
        'user_agent' => 'agent'
    );

    //--------------------------------------------------------------------------
    /**
     * 整理 moduleName 確保名稱規格一致
     *
     * @param type $moduleName
     * @return string
     */
    public function checkModuleName($moduleName) {
        $moduleName = trim($moduleName, '\\/');
        $moduleName = preg_replace('/\\//', '\\', $moduleName);

        $last_slash = strrpos($moduleName, '\\');

        $subdir = '';

        if (isset($last_slash)) {
            $subdir = substr($moduleName, 0, ++$last_slash);
            $moduleName = substr($moduleName, $last_slash);
        }

        $className = $subdir . ucfirst($moduleName);

        return $className;
    }

    //--------------------------------------------------------------------------

    /**
     * load_spec_class() 用到
     *
     * @param string $module
     * @return type
     */
    public function getClassIndexName($class, $prefix = FALSE) {
        $class = '\\' . ltrim($class, '\\');
        $indexName = $class;

        if (is_bool($prefix)) {
            if ($prefix) {
                $indexName = $indexName.'::class';
            }
        } else {
            $indexName = $prefix . $indexName;
        }

        return $indexName;
    }

    //--------------------------------------------------------------------------
    /**
     * core, library varName
     *
     * @param type $module
     * @return type
     */
    public function getModuleVarName($module) {
        $module = strtolower($module);
        $module = trim($module, '\\/');

        if (isset($this->_ci_varmap[$module])) {
            $module = $this->_ci_varmap[$module];
        }

        //$preg = '/(?:\\\\|\\/)/';
        $separator = preg_quote('\\');
        $preg = sprintf('/(?:%s|\\/)/', $separator);

        $module = preg_replace($preg, '_', $module);
        return $module;
    }

}
