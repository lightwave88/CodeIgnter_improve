<?php

namespace system;

defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 列出 Output 通用的 API
 * 方便整理
 */
abstract class CI_OutputABS {   
    
    // --------------------------------------------------------------------

    /**
     * Set Header
     *
     * Lets you set a server header which will be sent with the final output.
     *
     * Note: If a file is cached, headers will not be sent.
     * @todo	We need to figure out how to permit headers to be cached.
     *
     * @param	string	$header		Header
     * @param	bool	$replace	Whether to replace the old header value, if already set
     * @return	CI_Output
     */
    abstract public function set_header($header, $replace = TRUE);

    // --------------------------------------------------------------------

    /**
     * Set Content-Type Header
     *
     * @param	string	$mime_type	Extension of the file we're outputting
     * @param	string	$charset	Character set (default: NULL)
     * @return	CI_Output
     */
    abstract public function set_content_type($mime_type, $charset = NULL);

    // --------------------------------------------------------------------

    /**
     * Get Current Content-Type Header
     *
     * @return	string	'text/html', if not already set
     */
    abstract public function get_content_type();

    // --------------------------------------------------------------------

    /**
     * Get Header
     *
     * @param	string	$header
     * @return	string
     */
    abstract public function get_header($header);

    // --------------------------------------------------------------------

    /**
     * Set HTTP Status Header
     *
     * As of version 1.7.2, this is an alias for common function
     * set_status_header().
     *
     * @param	int	$code	Status code (default: 200)
     * @param	string	$text	Optional message
     * @return	CI_Output
     */
    abstract public function set_status_header($code = 200, $text = '');


    // --------------------------------------------------------------------

    /**
     * Byte-safe strlen()
     *
     * @param	string	$str
     * @return	int
     */
    public static function strlen($str) {
        return (self::$func_overload) ? mb_strlen($str, '8bit') : strlen($str);
    }

    // --------------------------------------------------------------------

    /**
     * Byte-safe substr()
     *
     * @param	string	$str
     * @param	int	$start
     * @param	int	$length
     * @return	string
     */
    public static function substr($str, $start, $length = NULL) {
        if (self::$func_overload) {
            // mb_substr($str, $start, null, '8bit') returns an empty
            // string on PHP 5.3
            isset($length) OR $length = ($start >= 0 ? self::strlen($str) - $start : -$start);
            return mb_substr($str, $start, $length, '8bit');
        }

        return isset($length) ? substr($str, $start, $length) : substr($str, $start);
    }

}
