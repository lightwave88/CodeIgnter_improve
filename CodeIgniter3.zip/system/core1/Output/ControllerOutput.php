<?php

namespace system;

defined('BASEPATH') OR exit('No direct script access allowed');

if (!class_exists('CI_Output')) {
    require_once(__DIR__ . '/Output.php');
}

/**
 * 與 controller 綁定的 output
 * 
 * 
 */
class CI_ControllerOutput extends CI_Output {

    // 全域 Output
    protected $__globalOutput;
    protected $container;

    public function __construct(\system\CI_Container $container) {
        $this->container = $container;
        $this->__globalOutput;
    }

}
