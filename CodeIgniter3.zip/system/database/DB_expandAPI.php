<?php

namespace DB;

abstract class CI_DB_expandAPI {

    /**
     * 外层的包裹(CI_DB)
     * 
     * @var type 
     */
    protected $wrap;

    // --------------------------------------------------------------------
    public function __construct($wrap) {
        $this->wrap = $wrap;
    }

    public function __call($key, $args) {
        if (method_exists($this, $key)) {
            return call_user_func_array($this, $key, $args);
        } else if (method_exists($this->wrap, $key)) {
            return call_user_func_array(array($this->wrap, $key), $args);
        } else {
            throw new Exception(sprintf('fun(%s) no exists', $key));
        }
    }

    public function __get($key) {
        if (property_exists($this, $key)) {
            return $this->$key;
        } else {
            return $this->wrap->$key;
        }
    }

    public function __set($key, $value) {
        if (property_exists($this, $key)) {
            $this->$key = $value;
        } else {
            $this->wrap->$key = $value;
        }
    }

}
