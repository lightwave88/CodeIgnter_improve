<?php

abstract class CI_DB extends CI_DB_driver {

    protected $api_expands = array();

    //--------------------------------------------------------------------------
    /**
     * 增加對 CI_DB_driver 的 method API 的擴展物件
     * 
     * @param \DB\CI_DB_extendAPI $expand
     */
    public function add_api_expand(\DB\CI_DB_expandAPI $expand) {
        $this->api_expands[] = $expand;
    }

    //--------------------------------------------------------------------------
    public function __call($key, $args) {
        if (method_exists($this, $key)) {
            return call_user_func_array($this, $key, $args);
        } else {
            // 從 $$this->api_expands 中找出有實作該 method 的物件
            $i = count($$this->api_expands);
            for (; $i >= 0; $i--) {
                $extand = $$this->api_expands[$i];

                if (method_exists($extand, $key)) {
                    return call_user_func_array(array($extand, $key), $args);
                }
            }
        }
        throw new Exception(sprintf('method DB->%s no exists', $key));
    }

}
