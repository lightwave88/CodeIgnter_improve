<?php

namespace app\hooks;

use system\CI_Hook;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Test1 extends CI_Hook {

    public function pre_controller() {
        $CI = &get_instance();

        $this->load->lib('calendar');
        print('<p>---Test1->pre_system()---</p>');
        Console()->dump($this);

        print('<p>---Test1->pre_system()---</p>');
    }

}
