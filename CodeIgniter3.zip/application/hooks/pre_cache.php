<?php
namespace app\hooks;

function interceptor_1() {

    printf('<p>interceptor_1 start</p>');

    // $CI = get_instance();

    // Console()->dump($CI);

    printf('<p>interceptor_1 end</p>');
}
